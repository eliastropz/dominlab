(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"Banner_News_300x600px_v3_atlas_1", frames: [[0,227,500,300],[0,0,1081,225],[502,227,500,300],[344,529,263,80],[0,529,342,95]]}
];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.ignorePause = false;
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib.CachedBmp_15 = function() {
	this.initialize(ss["Banner_News_300x600px_v3_atlas_1"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_14 = function() {
	this.initialize(ss["Banner_News_300x600px_v3_atlas_1"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_13 = function() {
	this.initialize(ss["Banner_News_300x600px_v3_atlas_1"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_12 = function() {
	this.initialize(ss["Banner_News_300x600px_v3_atlas_1"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_11 = function() {
	this.initialize(ss["Banner_News_300x600px_v3_atlas_1"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.News_17_12 = function() {
	this.initialize(img.News_17_12);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,3000,2000);// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop, this.reversed));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.Tween4 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.CachedBmp_15();
	this.instance.setTransform(-125.05,-74.95,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-125,-74.9,250,150);


(lib.Tween3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#025E9F").s().p("AArD/IgzgNQAFgTAriNQAkhxAEgvIgZAHIAIhFIAlgPQAMg3gBg8QAmATAzAJIgLAwIgBATIAogJIgOBQIgwALIgKAZQgFAdgkCPQgYBgAABHQgUgJgcgHgAFXDBQg0gTAIglQACiGBdh/QANgbAvAMQAnANANAdQAPAhgSA5QgqgMgQAAIgCgdQg0BJgGBbQAhgjADgFQACACAYAKQAeAMADgBQglBDgfAVQgSAMgUAAQgPAAgQgGgAmXDBQg0gTAJglQACiGBdh/QAMgbAvAMQAnANANAdQAPAhgRA5QgrgMgQAAIgBgdQg0BIgGBcQAhgjACgFQADADAYAJQAdAMAEgBQglBDgfAVQgSAMgVAAQgPAAgQgGgAjUC0QgVgJgYgEIABgEQArieARiZIAnAOQAYAHAfACIgCANQAdgRASgEIgUBeIgwAJQgUBIgIAoQgOA/gDA0QgNgEgdgNgACvCjQAXhNAoifIADhGQAwATAdACQgsDJgJB1QgwgVgqgMgAhnCjQAXhNAoifIAChGQAvATAeACQgsDJgJB1QgvgVgqgMgAIJCxQgmgMANgxQAHg0AfgzQATgpAcAMIBOATIAWg9QALgggDgKQgOgBgrBGQgUgTgsgJQAYg3AfgTQAigWAtAVQAcALALANQAOAQgIAXQgnB/ABCEQg3gPgkABIACgJQgeAZgIABIgFABQgQAAgogPgAJgAmIghBeQgGAaAZAEQAfgEAEgoIAYhjQgJgEgIAAQgUAAgIAXgArRCxQgmgMANgxQAHgyAfg1QATgpAcAMIBOATIAWg9QALgggDgKQgOgBgrBGQgUgTgsgJQAYg3AfgTQAigWAtAVQAcALALANQAOAQgIAXQgnB/ABCEQg3gPgkABIACgJQgeAZgIABIgFABQgQAAgogPgAp6AmIghBeQgGAaAZAEQAfgEAEgoIAYhjQgJgEgIAAQgUAAgIAXgAEIicQgNgOAAgTQAAgTANgOQANgOATAAQASAAANAOQANAOAAATQAAATgNAOQgNAOgSAAQgTAAgNgOgAgajGQANgIAQgRIAcgdIArAvIgyA2g");
	this.shape.setTransform(-0.0107,0.028,1.4131,1.4131);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-106,-38.3,212,76.69999999999999);


(lib.Tween2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.News_17_12();
	this.instance.setTransform(-310.5,-207,0.207,0.207);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-310.5,-207,621,414);


(lib.Tween1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.News_17_12();
	this.instance.setTransform(-310.5,-207,0.207,0.207);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-310.5,-207,621,414);


(lib.Text_News = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.CachedBmp_14();
	this.instance.setTransform(-106.25,-22,0.1966,0.1966);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Text_News, new cjs.Rectangle(-106.2,-22,212.5,44.3), null);


(lib.Slogan = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.CachedBmp_13();
	this.instance.setTransform(-125.05,-74.95,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Slogan, new cjs.Rectangle(-125,-74.9,250,150), null);


(lib.Logotipo = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#025E9F").s().p("AArD/IgzgNQAFgTAriNQAkhxAEgvIgZAHIAIhFIAlgPQAMg3gBg8QAmATAzAJIgLAwIgBATIAogJIgOBQIgwALIgKAZQgFAdgkCPQgYBgAABHQgUgJgcgHgAFXDBQg0gTAIglQACiGBdh/QANgbAvAMQAnANANAdQAPAhgSA5QgqgMgQAAIgCgdQg0BJgGBbQAhgjADgFQACACAYAKQAeAMADgBQglBDgfAVQgSAMgUAAQgPAAgQgGgAmXDBQg0gTAJglQACiGBdh/QAMgbAvAMQAnANANAdQAPAhgRA5QgrgMgQAAIgBgdQg0BIgGBcQAhgjACgFQADADAYAJQAdAMAEgBQglBDgfAVQgSAMgVAAQgPAAgQgGgAjUC0QgVgJgYgEIABgEQArieARiZIAnAOQAYAHAfACIgCANQAdgRASgEIgUBeIgwAJQgUBIgIAoQgOA/gDA0QgNgEgdgNgACvCjQAXhNAoifIADhGQAwATAdACQgsDJgJB1QgwgVgqgMgAhnCjQAXhNAoifIAChGQAvATAeACQgsDJgJB1QgvgVgqgMgAIJCxQgmgMANgxQAHg0AfgzQATgpAcAMIBOATIAWg9QALgggDgKQgOgBgrBGQgUgTgsgJQAYg3AfgTQAigWAtAVQAcALALANQAOAQgIAXQgnB/ABCEQg3gPgkABIACgJQgeAZgIABIgFABQgQAAgogPgAJgAmIghBeQgGAaAZAEQAfgEAEgoIAYhjQgJgEgIAAQgUAAgIAXgArRCxQgmgMANgxQAHgyAfg1QATgpAcAMIBOATIAWg9QALgggDgKQgOgBgrBGQgUgTgsgJQAYg3AfgTQAigWAtAVQAcALALANQAOAQgIAXQgnB/ABCEQg3gPgkABIACgJQgeAZgIABIgFABQgQAAgogPgAp6AmIghBeQgGAaAZAEQAfgEAEgoIAYhjQgJgEgIAAQgUAAgIAXgAEIicQgNgOAAgTQAAgTANgOQANgOATAAQASAAANAOQANAOAAATQAAATgNAOQgNAOgSAAQgTAAgNgOgAgajGQANgIAQgRIAcgdIArAvIgyA2g");
	this.shape.setTransform(-0.0107,0.028,1.4131,1.4131);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Logotipo, new cjs.Rectangle(-106,-38.3,212,76.69999999999999), null);


(lib.Btn = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.CachedBmp_12();
	this.instance.setTransform(-63.75,-20.35,0.5,0.5);

	this.instance_1 = new lib.CachedBmp_11();
	this.instance_1.setTransform(-85.4,-23.75,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Btn, new cjs.Rectangle(-85.4,-23.7,171,47.5), null);


// stage content:
(lib.Banner_News300x600pxv = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.actionFrames = [54];
	// timeline functions:
	this.frame_54 = function() {
		var _this = this;
		/*
		Clicking on the specified symbol instance executes a function.
		*/
		_this.Btn_assine.on('click', function(){
		/*
		Loads the URL in a new browser window.
		*/
		window.open('https://issuu.com/jornalacritica', '_blank');
		});
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(54).call(this.frame_54).wait(66));

	// Btn_assine
	this.instance = new lib.Btn();
	this.instance.setTransform(150,406.2);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.Btn_assine = new lib.Btn();
	this.Btn_assine.name = "Btn_assine";
	this.Btn_assine.setTransform(150,374.2);
	new cjs.ButtonHelper(this.Btn_assine, 0, 1, 1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance}]},39).to({state:[{t:this.Btn_assine}]},15).wait(66));
	this.timeline.addTween(cjs.Tween.get(this.instance).wait(39).to({_off:false},0).to({_off:true,y:374.2,alpha:1},15,cjs.Ease.sineOut).wait(66));

	// Slogan
	this.instance_1 = new lib.Slogan();
	this.instance_1.setTransform(150,245);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;

	this.instance_2 = new lib.Tween4("synched",0);
	this.instance_2.setTransform(150,258.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_1}]},25).to({state:[{t:this.instance_2}]},14).wait(81));
	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(25).to({_off:false},0).to({_off:true,y:258.7,alpha:1,mode:"synched",startPosition:0},14,cjs.Ease.quartOut).wait(81));

	// Logo
	this.instance_3 = new lib.Logotipo();
	this.instance_3.setTransform(150,204.55);
	this.instance_3.alpha = 0;
	this.instance_3._off = true;

	this.instance_4 = new lib.Tween3("synched",0);
	this.instance_4.setTransform(150,132.55);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_3}]},14).to({state:[{t:this.instance_4}]},11).wait(95));
	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(14).to({_off:false},0).to({_off:true,y:132.55,alpha:1,mode:"synched",startPosition:0},11,cjs.Ease.quintIn).wait(95));

	// Text_News
	this.instance_5 = new lib.Text_News();
	this.instance_5.setTransform(150.25,53.85,2.5433,2.5433,0,0,0,0.1,0);
	this.instance_5.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).to({regX:0,scaleX:1,scaleY:1,x:150,alpha:1},16).wait(104));

	// Mockup
	this.instance_6 = new lib.Tween1("synched",0);
	this.instance_6.setTransform(222.5,751);

	this.instance_7 = new lib.Tween2("synched",0);
	this.instance_7.setTransform(222.5,527);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_6}]}).to({state:[{t:this.instance_7}]},89).wait(31));
	this.timeline.addTween(cjs.Tween.get(this.instance_6).to({_off:true,y:527},89,cjs.Ease.cubicOut).wait(31));

	// BG
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("EgZ7gxYMAz3AAAMAAABixMgz3AAAg");
	this.shape.setTransform(150.025,300.025);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#ECECEC").s().p("EgZ7AxZMAAAhixMAz3AAAMAAABixg");
	this.shape_1.setTransform(150.025,300.025);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(120));

	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(29.8,283,503.2,675);
// library properties:
lib.properties = {
	id: '0E918C278F537B43BB185D950A97CFBF',
	width: 300,
	height: 600,
	fps: 30,
	color: "#ECECEC",
	opacity: 1.00,
	manifest: [
		{src:"images/News_17_12.png", id:"News_17_12"},
		{src:"images/Banner_News_300x600px_v3_atlas_1.png", id:"Banner_News_300x600px_v3_atlas_1"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['0E918C278F537B43BB185D950A97CFBF'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused || stageChild.ignorePause){
			stageChild.syncStreamSounds();
		}
	}
}
an.handleFilterCache = function(event) {
	if(!event.paused){
		var target = event.target;
		if(target){
			if(target.filterCacheList){
				for(var index = 0; index < target.filterCacheList.length ; index++){
					var cacheInst = target.filterCacheList[index];
					if((cacheInst.startFrame <= target.currentFrame) && (target.currentFrame <= cacheInst.endFrame)){
						cacheInst.instance.cache(cacheInst.x, cacheInst.y, cacheInst.w, cacheInst.h);
					}
				}
			}
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;